# ==============================================================================
# TOURISM ANALYTICS DASHBOARD - FULL STACK R SERVER (app.r)
# Backend: Pure R Programming & Plumber REST API
# Database: Pure R Program Database Engine (database.r + RDS Data Frames)
# Analytics: Pure R Statistical Engine (data_analytics.r + dplyr)
# Resilience: Zero-Crash Error Catchers & Auto-Recovery Server Architecture
# ==============================================================================

cat("\n=======================================================\n")
cat("   TOURISM ANALYTICS DASHBOARD (PURE R SERVER & DB)\n")
cat("=======================================================\n\n")

suppressPackageStartupMessages({
  library(plumber)
  library(httpuv)
  library(jsonlite)
  library(dplyr)
})

# Set working directory to script location automatically if invoked from outside
tryCatch({
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("--file=", args, value = TRUE)
  if (length(file_arg) > 0) {
    script_path <- sub("--file=", "", file_arg[1])
    script_dir <- dirname(normalizePath(script_path))
    if (dir.exists(script_dir) && getwd() != script_dir) {
      setwd(script_dir)
    }
  }
}, error = function(e) {})

# Initialize Pure R Database
if (file.exists("database.r")) {
  source("database.r")
} else if (file.exists("database.R")) {
  source("database.R")
}

if (file.exists("data_analytics.r")) {
  source("data_analytics.r")
} else {
  source("data_analytics.R")
}

# Create Plumber Router
pr_file <- if (file.exists("plumber.r")) "plumber.r" else "plumber.R"
pr <- pr(pr_file)

# Global Error Handler: Intercepts all uncaught exceptions cleanly
pr_set_error(pr, function(req, res, err) {
  res$status <- 500
  res$setHeader("Content-Type", "application/json; charset=utf-8")
  res$setHeader("Access-Control-Allow-Origin", "*")
  res$setHeader("Access-Control-Allow-Private-Network", "true")
  list(
    success = FALSE,
    error = "Internal Server Error",
    message = if (inherits(err, "error")) err$message else as.character(err)
  )
})

# Global 404 Not Found Handler
pr_set_404(pr, function(req, res) {
  res$status <- 404
  res$setHeader("Content-Type", "application/json; charset=utf-8")
  res$setHeader("Access-Control-Allow-Origin", "*")
  res$setHeader("Access-Control-Allow-Private-Network", "true")
  list(
    success = FALSE,
    error = "Not Found",
    message = sprintf("Endpoint '%s' not found.", if (!is.null(req$PATH_INFO)) req$PATH_INFO else "")
  )
})

# Static asset router fallback
pr_static(pr, "/public", "public")

port <- as.numeric(Sys.getenv("PORT", "8000"))
host <- "0.0.0.0"

cat("[R-SERVER] Pure R Database Engine Active (database.r)\n")
cat("[R-SERVER] Persistent RDS Data Tables in data/ (users.rds, destinations.rds, tourism_data.rds)\n")
cat("[R-SERVER] Pure R Analytics & Linear Models Engine Active (data_analytics.r)\n")
cat("[R-SERVER] Web Modules Active:\n")
cat("           User Management\n")
cat("           Tourism Data Collection\n")
cat("           Data Analysis\n")
cat("           Visualization Dashboard\n")
cat("           Reports Generation\n\n")
cat(sprintf(">>> SERVER ACTIVE AT: http://localhost:%d <<<\n", port))
cat("=======================================================\n\n")

# Automatically launch Web Dashboard in default browser
dashboard_url <- sprintf("http://localhost:%d/public/index.html", port)
tryCatch({
  utils::browseURL(dashboard_url)
}, error = function(e) {})

# Run Plumber Server
pr_run(pr, host = host, port = port)

