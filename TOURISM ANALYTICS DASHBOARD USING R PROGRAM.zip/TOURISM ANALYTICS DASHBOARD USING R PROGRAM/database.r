# ==============================================================================
# TOURISM ANALYTICS DASHBOARD - PURE R DATABASE ENGINE (database.r)
# Technology: R Programming Data Frames & Persistent RDS Binary Storage
# Features: Dynamic Input-Based Admin/Customer Auth, User/Destination/Booking CRUD
# Resilience: In-Memory Caching & Lock-Safe Atomic RDS Persistence (OneDrive Proof)
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
})

# Ensure data directory exists
if (!dir.exists("data")) {
  dir.create("data", recursive = TRUE)
}

# R Database File Paths (.rds)
DB_USERS_PATH        <- "data/users.rds"
DB_CUSTOMERS_PATH    <- "data/customers.rds"
DB_DESTINATIONS_PATH <- "data/destinations.rds"
DB_TOURISM_PATH      <- "data/tourism_data.rds"

# In-Memory Database Cache (Eliminates OneDrive/OS File-Lock Latency & Collisions)
.db_cache <- new.env(parent = emptyenv())
.db_cache$users        <- NULL
.db_cache$customers    <- NULL
.db_cache$destinations <- NULL
.db_cache$tourism      <- NULL

# ------------------------------------------------------------------------------
# LOCK-SAFE RDS READ / WRITE HELPERS (Handles OneDrive Sync & File Contention)
# ------------------------------------------------------------------------------
safe_read_rds <- function(filepath, max_attempts = 5) {
  if (!file.exists(filepath)) return(NULL)
  for (attempt in seq_len(max_attempts)) {
    res <- tryCatch({
      readRDS(filepath)
    }, error = function(e) {
      if (attempt < max_attempts) Sys.sleep(0.04 * attempt)
      NULL
    })
    if (!is.null(res)) return(res)
  }
  return(NULL)
}

safe_save_rds <- function(object, filepath, max_attempts = 5) {
  tmp_file <- sprintf("%s.tmp.%d_%d", filepath, Sys.getpid(), as.integer(runif(1, 1000, 9999)))
  for (attempt in seq_len(max_attempts)) {
    success <- tryCatch({
      saveRDS(object, tmp_file)
      if (file.exists(tmp_file)) {
        file.rename(tmp_file, filepath)
        TRUE
      } else {
        FALSE
      }
    }, error = function(e) {
      # Fallback to direct saveRDS if rename failed
      tryCatch({
        saveRDS(object, filepath)
        TRUE
      }, error = function(e2) {
        if (attempt < max_attempts) Sys.sleep(0.04 * attempt)
        FALSE
      })
    })
    if (file.exists(tmp_file)) tryCatch(unlink(tmp_file), error = function(e) NULL)
    if (isTRUE(success)) return(TRUE)
  }
  return(FALSE)
}

# ------------------------------------------------------------------------------
# 1. DATABASE SCHEMA & INITIALIZATION (Pure R Engine)
# ------------------------------------------------------------------------------
db_init <- function() {
  cat("[R-Database] Initializing pure R RDS database engine...\n")
  
  # 1. Users Table (Admin & Staff Accounts)
  users_df <- safe_read_rds(DB_USERS_PATH)
  if (is.null(users_df) || nrow(users_df) == 0) {
    users_df <- data.frame(
      id = c(1, 2),
      username = c("admin", "jothika"),
      password = c("admin123", "jothika123"),
      full_name = c("Administrator", "Jothika Saravanan"),
      email = c("admin@tourism.gov.in", "jothika@tourism.gov.in"),
      role = c("Administrator", "Admin Staff"),
      department = c("Directorate of Tourism", "Analytics Wing"),
      status = c("Active", "Active"),
      last_login = c(format(Sys.time(), "%Y-%m-%d %H:%M:%S"), format(Sys.time() - 86400, "%Y-%m-%d %H:%M:%S")),
      created_at = c(format(Sys.time() - 604800, "%Y-%m-%d %H:%M:%S"), format(Sys.time() - 259200, "%Y-%m-%d %H:%M:%S")),
      stringsAsFactors = FALSE
    )
    safe_save_rds(users_df, DB_USERS_PATH)
    cat("[R-Database] Created data/users.rds\n")
  } else {
    # Standardize System Administrator to Administrator
    if ("full_name" %in% names(users_df) && any(users_df$full_name == "System Administrator", na.rm = TRUE)) {
      users_df$full_name[users_df$full_name == "System Administrator"] <- "Administrator"
      safe_save_rds(users_df, DB_USERS_PATH)
    }
  }
  .db_cache$users <- users_df

  # 2. Customers Table (Customer Accounts)
  customers_df <- safe_read_rds(DB_CUSTOMERS_PATH)
  if (is.null(customers_df) || nrow(customers_df) == 0) {
    customers_df <- data.frame(
      id = c(1),
      username = c("customer1"),
      password = c("pass123"),
      full_name = c("Rahul Sharma"),
      email = c("rahul@gmail.com"),
      phone = c("9876543210"),
      city = c("Chennai"),
      created_at = c(format(Sys.time() - 86400, "%Y-%m-%d %H:%M:%S")),
      last_login = c(format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
      stringsAsFactors = FALSE
    )
    safe_save_rds(customers_df, DB_CUSTOMERS_PATH)
    cat("[R-Database] Created data/customers.rds\n")
  }
  .db_cache$customers <- customers_df

  # 3. Destinations Table (Tamil Nadu Destinations)
  destinations_df <- safe_read_rds(DB_DESTINATIONS_PATH)
  if (is.null(destinations_df) || nrow(destinations_df) == 0) {
    destinations_df <- data.frame(
      id = 1:8,
      name = c("Chennai", "Madurai", "Ooty", "Kodaikanal", "Rameswaram", "Mahabalipuram", "Coimbatore", "Thanjavur"),
      base_cost = c(3500, 3000, 4500, 4200, 3800, 3200, 2800, 3000),
      popular_season = c("Winter", "Spring", "Summer", "Summer", "Festival", "Winter", "Fall", "Winter"),
      availability = c("Available", "Available", "Limited", "Available", "Available", "Available", "Available", "Available"),
      visitor_level = c("High", "Very High", "High", "High", "Medium", "Medium", "Medium", "Medium"),
      category = c("Heritage / Coastal", "Temple Heritage", "Hill Station", "Hill Station", "Pilgrimage / Coastal", "UNESCO Heritage", "Nature / Commercial", "Chola Architecture"),
      rating = c(4.8, 4.9, 4.9, 4.8, 4.7, 4.8, 4.6, 4.9),
      latitude = c(13.0827, 9.9252, 11.4102, 10.2381, 9.2876, 12.6269, 11.0168, 10.7870),
      longitude = c(80.2707, 78.1198, 76.6950, 77.4892, 79.3129, 80.1927, 76.9558, 79.1378),
      description = c(
        "Capital & Gateway of South India, famous for Marina Beach & Fort St. George.",
        "Ancient Temple City with historical Meenakshi Amman Temple & Palace.",
        "Queen of Hill Stations in Nilgiris with Botanical Gardens & Toy Train.",
        "Princess of Hill Stations with pine forests, Kodai Lake & scenic viewpoints.",
        "Sacred Island destination with legendary Pamban Sea Bridge & coastal temples.",
        "UNESCO World Heritage Shore Temple town with ancient monolithic rock sculptures.",
        "Manchester of South India, nestled near Nilgiri foothills & nature trails.",
        "Great Living Chola Arts Capital featuring Brihadeeswarar Temple architecture."
      ),
      stringsAsFactors = FALSE
    )
    safe_save_rds(destinations_df, DB_DESTINATIONS_PATH)
    cat("[R-Database] Created data/destinations.rds\n")
  }
  .db_cache$destinations <- destinations_df

  # 4. Tourism / Bookings Data Table
  tourism_df <- safe_read_rds(DB_TOURISM_PATH)
  if (is.null(tourism_df) || nrow(tourism_df) == 0) {
    tourism_df <- data.frame(
      id = c(1, 2, 3, 4, 5, 6),
      booking_id = c("B001", "B002", "B003", "B004", "B005", "B006"),
      tourist_name = c("Rahul & Priya Sharma", "Prof. Natarajan & Group", "Anand & Shalini Kumar", "Vikramaditya Rao", "Dr. Karthik & Friends", "Meenakshi Sundaram"),
      starting_location = c("Chennai", "Madurai", "Chennai", "Bangalore", "Coimbatore", "Tiruchirappalli"),
      destination = c("Ooty", "Kodaikanal", "Rameswaram", "Mahabalipuram", "Ooty", "Thanjavur"),
      visitors = c(3, 4, 2, 2, 5, 4),
      travel_date = c("2026-05-15", "2026-06-10", "2026-08-20", "2026-01-12", "2026-05-22", "2026-02-18"),
      days = c(3, 2, 3, 2, 4, 2),
      season = c("Summer", "Summer", "Festival", "Winter", "Summer", "Winter"),
      travel_type = c("Family", "Group", "Couple", "Couple", "Group", "Family"),
      budget = c(25000, 22000, 18000, 15000, 48000, 24000),
      accommodation = c("Yes", "Yes", "Yes", "Yes", "Yes", "No"),
      availability = c("Limited", "Available", "Available", "Available", "Limited", "Available"),
      estimated_cost = c(20250, 16800, 11400, 6400, 45000, 12000),
      booking_status = c("Confirmed", "Confirmed", "Confirmed", "Confirmed", "Confirmed", "Confirmed"),
      created_at = c("2026-05-01 10:30:00", "2026-05-03 14:15:00", "2026-05-05 09:45:00", "2026-01-02 11:20:00", "2026-05-10 16:30:00", "2026-02-01 12:00:00"),
      stringsAsFactors = FALSE
    )
    safe_save_rds(tourism_df, DB_TOURISM_PATH)
    cat("[R-Database] Created data/tourism_data.rds\n")
  }
  .db_cache$tourism <- tourism_df
}

# ------------------------------------------------------------------------------
# 2. ADMIN USER DATABASE OPERATIONS
# ------------------------------------------------------------------------------
db_get_users <- function() {
  if (is.null(.db_cache$users)) {
    df <- safe_read_rds(DB_USERS_PATH)
    if (is.null(df)) {
      db_init()
      df <- .db_cache$users
    } else {
      .db_cache$users <- df
    }
  }
  df <- .db_cache$users
  if (is.null(df) || nrow(df) == 0) {
    db_init()
    df <- .db_cache$users
  }
  if (!"full_name" %in% names(df)) df$full_name <- df$username
  if (!"email" %in% names(df)) df$email <- ""
  if (!"department" %in% names(df)) df$department <- "Directorate of Tourism"
  if (!"status" %in% names(df)) df$status <- "Active"
  df$full_name[is.na(df$full_name)] <- df$username[is.na(df$full_name)]
  df$full_name[df$full_name == "System Administrator"] <- "Administrator"
  df$email[is.na(df$email)] <- ""
  df
}

db_save_users_df <- function(df) {
  .db_cache$users <- df
  safe_save_rds(df, DB_USERS_PATH)
}

# ------------------------------------------------------------------------------
# Universal Smart Authentication Engine (Checks both Admin & Customer databases)
# ------------------------------------------------------------------------------
db_universal_authenticate <- function(username, password) {
  u_input <- tolower(trimws(as.character(username)))
  p_input <- trimws(as.character(password))
  
  if (u_input == "" || p_input == "") {
    return(list(
      authenticated = FALSE,
      message = "Please enter Username/Email and Password.",
      role = NULL,
      user = NULL,
      customer = NULL
    ))
  }
  
  # 1. Check Admin Users Table (data/users.rds)
  users_df <- db_get_users()
  user_match <- users_df %>% filter(
    tolower(username) == u_input | (email != "" & tolower(email) == u_input)
  )
  
  if (nrow(user_match) > 0) {
    user <- user_match[1, ]
    if (user$password == p_input) {
      now_str <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
      users_df$last_login[users_df$id == user$id] <- now_str
      db_save_users_df(users_df)
      
      role_val <- if (!is.null(user$role) && user$role != "") as.character(user$role) else "Administrator"
      user_obj <- list(
        id = user$id,
        username = user$username,
        full_name = user$full_name,
        email = user$email,
        role = role_val,
        department = user$department,
        last_login = now_str
      )
      
      return(list(
        authenticated = TRUE,
        role = role_val,
        role_type = "Admin",
        is_admin = TRUE,
        is_customer = FALSE,
        message = sprintf("Administrator Login Successful! Welcome %s.", user$full_name),
        user = user_obj,
        customer = user_obj
      ))
    } else {
      return(list(
        authenticated = FALSE,
        message = "Incorrect password. Please verify your password and try again.",
        role = "Admin",
        user = NULL,
        customer = NULL
      ))
    }
  }
  
  # 2. Check Customers Table (data/customers.rds)
  cust_df <- db_get_customers()
  cust_match <- cust_df %>% filter(
    tolower(username) == u_input | (email != "" & tolower(email) == u_input)
  )
  
  if (nrow(cust_match) > 0) {
    c_row <- cust_match[1, ]
    if (c_row$password == p_input) {
      now_str <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
      cust_df$last_login[cust_df$id == c_row$id] <- now_str
      db_save_customers_df(cust_df)
      
      cust_obj <- list(
        id = c_row$id,
        username = c_row$username,
        full_name = c_row$full_name,
        email = c_row$email,
        phone = c_row$phone,
        city = c_row$city,
        role = "Customer",
        last_login = now_str
      )
      
      return(list(
        authenticated = TRUE,
        role = "Customer",
        role_type = "Customer",
        is_admin = FALSE,
        is_customer = TRUE,
        message = sprintf("Welcome, %s!", c_row$full_name),
        customer = cust_obj,
        user = cust_obj
      ))
    } else {
      return(list(
        authenticated = FALSE,
        message = "Incorrect password. Please verify your password and try again.",
        role = "Customer",
        user = NULL,
        customer = NULL
      ))
    }
  }
  
  return(list(
    authenticated = FALSE,
    message = sprintf("Account '%s' not found. Please register first.", username),
    role = NULL,
    user = NULL,
    customer = NULL
  ))
}

# Admin Authentication (Input-based vs Database - Seamless Smart Router)
db_authenticate <- function(username, password) {
  res <- db_universal_authenticate(username, password)
  if (isTRUE(res$authenticated)) {
    if (isTRUE(res$is_customer)) {
      return(list(
        authenticated = TRUE,
        is_customer = TRUE,
        is_admin = FALSE,
        role = "Customer",
        role_type = "Customer",
        message = sprintf("Customer Account Detected – Welcome %s!", res$customer$full_name),
        customer = res$customer,
        user = res$customer
      ))
    } else {
      return(list(
        authenticated = TRUE,
        is_admin = TRUE,
        is_customer = FALSE,
        role = res$role,
        role_type = "Admin",
        message = sprintf("Administrator Login Successful! Welcome %s.", res$user$full_name),
        user = res$user,
        customer = res$user
      ))
    }
  }
  return(res)
}

# Admin Registration / Admin Creation
db_register_admin <- function(username, password, full_name, email = "", department = "Directorate of Tourism") {
  users_df <- db_get_users()
  u_clean <- trimws(as.character(username))
  p_clean <- trimws(as.character(password))
  fn_clean <- trimws(as.character(full_name))
  em_clean <- trimws(as.character(email))
  dep_clean <- trimws(as.character(department))
  if (dep_clean == "") dep_clean <- "Directorate of Tourism"
  
  if (nchar(fn_clean) < 2) {
    return(list(success = FALSE, message = "Please enter Admin Full Name (minimum 2 characters)."))
  }
  if (nchar(u_clean) < 3) {
    return(list(success = FALSE, message = "Admin Username must be at least 3 characters long."))
  }
  if (nchar(p_clean) < 4) {
    return(list(success = FALSE, message = "Password must be at least 4 characters long."))
  }
  
  # Check duplicate username
  if (tolower(u_clean) %in% tolower(users_df$username)) {
    return(list(success = FALSE, message = sprintf("Admin username '%s' already exists. Please choose a different username.", u_clean)))
  }
  
  # Check duplicate email
  if (em_clean != "" && "email" %in% names(users_df)) {
    valid_emails <- users_df$email[users_df$email != "" & !is.na(users_df$email)]
    if (tolower(em_clean) %in% tolower(valid_emails)) {
      return(list(success = FALSE, message = sprintf("Email address '%s' is already in use by another admin account.", em_clean)))
    }
  }
  
  new_id <- if (nrow(users_df) > 0) max(c(0, as.numeric(users_df$id)), na.rm = TRUE) + 1 else 1
  now_str <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  
  new_row <- data.frame(
    id = new_id,
    username = u_clean,
    password = p_clean,
    full_name = fn_clean,
    email = em_clean,
    role = "Administrator",
    department = dep_clean,
    status = "Active",
    last_login = "Never",
    created_at = now_str,
    stringsAsFactors = FALSE
  )
  
  users_df <- bind_rows(users_df, new_row)
  db_save_users_df(users_df)
  
  list(
    success = TRUE,
    id = new_id,
    message = "Admin Account Created Successfully – Please Login",
    user = list(
      id = new_id,
      username = u_clean,
      full_name = fn_clean,
      role = "Administrator"
    )
  )
}

db_add_user <- function(username, password, full_name, email, role, department) {
  users_df <- db_get_users()
  u_clean <- trimws(as.character(username))
  if (tolower(u_clean) %in% tolower(users_df$username)) {
    return(list(success = FALSE, message = sprintf("Username '%s' already exists.", u_clean)))
  }
  new_id <- if (nrow(users_df) > 0) max(c(0, as.numeric(users_df$id)), na.rm = TRUE) + 1 else 1
  now_str <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  
  new_row <- data.frame(
    id = new_id,
    username = u_clean,
    password = trimws(as.character(password)),
    full_name = trimws(as.character(full_name)),
    email = trimws(as.character(email)),
    role = role,
    department = department,
    status = "Active",
    last_login = "Never",
    created_at = now_str,
    stringsAsFactors = FALSE
  )
  users_df <- bind_rows(users_df, new_row)
  db_save_users_df(users_df)
  list(success = TRUE, id = new_id, message = sprintf("User '%s' added successfully.", u_clean))
}

db_delete_user <- function(id) {
  users_df <- db_get_users()
  target_id <- as.numeric(id)
  if (target_id == 1) return(list(success = FALSE, message = "Cannot delete primary administrator account."))
  if (!target_id %in% users_df$id) return(list(success = FALSE, message = "User not found."))
  
  users_df <- users_df %>% filter(id != target_id)
  db_save_users_df(users_df)
  list(success = TRUE, message = "User deleted successfully.")
}

# ------------------------------------------------------------------------------
# 3. CUSTOMER REGISTRATION & AUTHENTICATION (Pure R Engine)
# ------------------------------------------------------------------------------
db_get_customers <- function() {
  if (is.null(.db_cache$customers)) {
    df <- safe_read_rds(DB_CUSTOMERS_PATH)
    if (is.null(df)) {
      db_init()
      df <- .db_cache$customers
    } else {
      .db_cache$customers <- df
    }
  }
  df <- .db_cache$customers
  if (is.null(df) || nrow(df) == 0) {
    db_init()
    df <- .db_cache$customers
  }
  if (!"email" %in% names(df)) df$email <- ""
  if (!"phone" %in% names(df)) df$phone <- ""
  if (!"city" %in% names(df)) df$city <- "Chennai"
  if (!"created_at" %in% names(df)) df$created_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  if (!"last_login" %in% names(df)) df$last_login <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  df$email[is.na(df$email)] <- ""
  df$phone[is.na(df$phone)] <- ""
  df$city[is.na(df$city)] <- "Chennai"
  df
}

db_save_customers_df <- function(df) {
  .db_cache$customers <- df
  safe_save_rds(df, DB_CUSTOMERS_PATH)
}

db_register_customer <- function(username, password, full_name, email = "", phone = "", city = "Chennai") {
  cust_df <- db_get_customers()
  
  u_clean <- trimws(as.character(username))
  p_clean <- trimws(as.character(password))
  fn_clean <- trimws(as.character(full_name))
  em_clean <- trimws(as.character(email))
  ph_clean <- trimws(as.character(phone))
  ct_clean <- trimws(as.character(city))
  if (ct_clean == "") ct_clean <- "Chennai"
  
  # Validation
  if (nchar(fn_clean) < 2) {
    return(list(success = FALSE, message = "Please enter customer full name (minimum 2 characters)."))
  }
  if (nchar(u_clean) < 3) {
    return(list(success = FALSE, message = "Username must be at least 3 characters long."))
  }
  if (nchar(p_clean) < 4) {
    return(list(success = FALSE, message = "Password must be at least 4 characters long."))
  }
  if (em_clean == "" || !grepl("@", em_clean)) {
    return(list(success = FALSE, message = "Please enter a valid email address."))
  }
  if (ph_clean == "" || nchar(ph_clean) < 7) {
    return(list(success = FALSE, message = "Please enter a valid phone number."))
  }
  
  # Case-insensitive duplicate check in customers table
  if (tolower(u_clean) %in% tolower(cust_df$username)) {
    return(list(success = FALSE, message = "Username already exists. Please choose a different username."))
  }
  
  # Check against admin usernames
  users_df <- db_get_users()
  if (tolower(u_clean) %in% tolower(users_df$username)) {
    return(list(success = FALSE, message = "Username already exists. Please choose a different username."))
  }
  
  # Case-insensitive email check
  if ("email" %in% names(cust_df)) {
    valid_emails <- cust_df$email[cust_df$email != "" & !is.na(cust_df$email)]
    if (tolower(em_clean) %in% tolower(valid_emails)) {
      return(list(success = FALSE, message = sprintf("Email address '%s' is already registered. Please sign in.", em_clean)))
    }
  }
  
  new_id <- if (nrow(cust_df) > 0) max(c(0, as.numeric(cust_df$id)), na.rm = TRUE) + 1 else 1
  now_str <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  
  new_row <- data.frame(
    id = new_id,
    username = u_clean,
    password = p_clean,
    full_name = fn_clean,
    email = em_clean,
    phone = ph_clean,
    city = ct_clean,
    created_at = now_str,
    last_login = now_str,
    stringsAsFactors = FALSE
  )
  
  cust_df <- bind_rows(cust_df, new_row)
  db_save_customers_df(cust_df)
  
  list(
    success = TRUE,
    message = "Registration Successful – Please Login",
    customer = list(
      id = new_id,
      username = u_clean,
      full_name = fn_clean,
      email = em_clean,
      phone = ph_clean,
      city = ct_clean,
      role = "Customer",
      created_at = now_str,
      last_login = now_str
    )
  )
}

# Customer Authentication (Input-based vs Database - Seamless Smart Router)
db_authenticate_customer <- function(username, password) {
  res <- db_universal_authenticate(username, password)
  if (isTRUE(res$authenticated)) {
    if (isTRUE(res$is_admin)) {
      return(list(
        authenticated = TRUE,
        is_admin = TRUE,
        is_customer = FALSE,
        role = res$role,
        role_type = "Admin",
        message = sprintf("Administrator Account Detected – Welcome %s!", res$user$full_name),
        user = res$user,
        customer = res$user
      ))
    } else {
      return(list(
        authenticated = TRUE,
        is_customer = TRUE,
        is_admin = FALSE,
        role = "Customer",
        role_type = "Customer",
        message = sprintf("Welcome, %s!", res$customer$full_name),
        customer = res$customer,
        user = res$customer
      ))
    }
  }
  return(res)
}

db_update_customer_profile <- function(id, full_name, email, phone, city = "", new_password = "") {
  cust_df <- db_get_customers()
  target_id <- as.numeric(id)
  
  if (!target_id %in% cust_df$id) {
    return(list(success = FALSE, message = "Customer record not found."))
  }
  
  idx <- which(cust_df$id == target_id)
  if (trimws(full_name) != "") cust_df$full_name[idx] <- trimws(full_name)
  if (trimws(email) != "") cust_df$email[idx] <- trimws(email)
  if (trimws(phone) != "") cust_df$phone[idx] <- trimws(phone)
  if (trimws(city) != "") cust_df$city[idx] <- trimws(city)
  if (trimws(new_password) != "") cust_df$password[idx] <- trimws(new_password)
  
  db_save_customers_df(cust_df)
  
  list(
    success = TRUE,
    message = "Profile updated successfully!",
    customer = list(
      id = cust_df$id[idx],
      username = cust_df$username[idx],
      full_name = cust_df$full_name[idx],
      email = cust_df$email[idx],
      phone = cust_df$phone[idx],
      city = cust_df$city[idx],
      role = "Customer"
    )
  )
}

# ------------------------------------------------------------------------------
# 4. DESTINATIONS DATABASE OPERATIONS
# ------------------------------------------------------------------------------
db_get_destinations <- function() {
  if (is.null(.db_cache$destinations)) {
    df <- safe_read_rds(DB_DESTINATIONS_PATH)
    if (is.null(df)) {
      db_init()
      df <- .db_cache$destinations
    } else {
      .db_cache$destinations <- df
    }
  }
  df <- .db_cache$destinations
  if (is.null(df) || nrow(df) == 0) {
    db_init()
    df <- .db_cache$destinations
  }
  if (!"ticket_price" %in% names(df) && "base_cost" %in% names(df)) {
    df$ticket_price <- df$base_cost
  }
  if (!"location" %in% names(df) && "category" %in% names(df)) {
    df$location <- "Tamil Nadu"
  }
  df
}

db_save_destinations_df <- function(df) {
  .db_cache$destinations <- df
  safe_save_rds(df, DB_DESTINATIONS_PATH)
}

db_get_destination_by_name <- function(dest_name) {
  df <- db_get_destinations()
  d_name <- tolower(trimws(as.character(dest_name)))
  res <- df %>% filter(tolower(name) == d_name)
  if (nrow(res) > 0) res[1, ] else NULL
}

# Admin adds destination dynamically
db_add_destination <- function(name, location = "Tamil Nadu", ticket_price = 1500, availability = "Available", popular_season = "All Season", category = "Tourist Attraction", description = "") {
  df <- db_get_destinations()
  name_clean <- trimws(as.character(name))
  loc_clean <- trimws(as.character(location))
  if (loc_clean == "") loc_clean <- "Tamil Nadu"
  price_num <- as.numeric(ticket_price)
  if (is.na(price_num) || price_num <= 0) price_num <- 1000
  avail_clean <- trimws(as.character(availability))
  if (avail_clean == "") avail_clean <- "Available"
  
  if (name_clean == "") {
    return(list(success = FALSE, message = "Destination name is required."))
  }
  
  # Check if destination already exists
  if (tolower(name_clean) %in% tolower(df$name)) {
    idx <- which(tolower(df$name) == tolower(name_clean))
    df$base_cost[idx] <- price_num
    if ("ticket_price" %in% names(df)) df$ticket_price[idx] <- price_num
    df$availability[idx] <- avail_clean
    if (loc_clean != "") df$category[idx] <- loc_clean
    db_save_destinations_df(df)
    return(list(
      success = TRUE,
      message = "Destination Added Successfully!",
      destination = df[idx, ]
    ))
  }
  
  new_id <- if (nrow(df) > 0) max(c(0, as.numeric(df$id)), na.rm = TRUE) + 1 else 1
  desc_text <- if (trimws(description) != "") trimws(description) else sprintf("Scenic destination in %s, featuring cultural landmarks and attractions.", loc_clean)
  
  new_row <- data.frame(
    id = new_id,
    name = name_clean,
    base_cost = price_num,
    popular_season = popular_season,
    availability = avail_clean,
    visitor_level = "Medium",
    category = loc_clean,
    rating = 4.8,
    latitude = 11.0,
    longitude = 78.0,
    description = desc_text,
    stringsAsFactors = FALSE
  )
  
  if ("ticket_price" %in% names(df)) new_row$ticket_price <- price_num
  if ("location" %in% names(df)) new_row$location <- loc_clean
  
  df <- bind_rows(df, new_row)
  db_save_destinations_df(df)
  
  list(
    success = TRUE,
    id = new_id,
    message = "Destination Added Successfully!",
    destination = new_row
  )
}

db_delete_destination <- function(id) {
  df <- db_get_destinations()
  target_id <- as.numeric(id)
  if (!target_id %in% df$id) {
    return(list(success = FALSE, message = "Destination not found in database."))
  }
  
  df <- df %>% filter(id != target_id)
  db_save_destinations_df(df)
  list(success = TRUE, message = "Destination deleted successfully.")
}

# ------------------------------------------------------------------------------
# 5. TOURISM DATASET & BOOKINGS OPERATIONS
# ------------------------------------------------------------------------------
db_get_tourism <- function(destination = "", season = "", travel_type = "", search = "") {
  if (is.null(.db_cache$tourism)) {
    df <- safe_read_rds(DB_TOURISM_PATH)
    if (is.null(df)) {
      db_init()
      df <- .db_cache$tourism
    } else {
      .db_cache$tourism <- df
    }
  }
  df <- .db_cache$tourism
  if (is.null(df) || nrow(df) == 0) {
    db_init()
    df <- .db_cache$tourism
  }
  
  if (!"booking_id" %in% names(df)) {
    df$booking_id <- sprintf("B%03d", df$id)
  }
  if (!"booking_status" %in% names(df)) {
    df$booking_status <- "Confirmed"
  }
  if (!"ticket_price" %in% names(df)) {
    df$ticket_price <- 0
  }
  if (!"subtotal" %in% names(df)) {
    df$subtotal <- df$budget
  }
  if (!"discount" %in% names(df)) {
    df$discount <- 0
  }
  
  if (nrow(df) > 0) {
    if (destination != "") df <- df %>% filter(destination == !!destination)
    if (season != "") df <- df %>% filter(season == !!season)
    if (travel_type != "") df <- df %>% filter(travel_type == !!travel_type)
    if (search != "") {
      s <- tolower(search)
      df <- df %>% filter(
        grepl(s, tolower(tourist_name)) |
        grepl(s, tolower(starting_location)) |
        grepl(s, tolower(destination)) |
        grepl(s, tolower(booking_id))
      )
    }
  }
  df %>% arrange(desc(id))
}

db_save_tourism_df <- function(df) {
  .db_cache$tourism <- df
  safe_save_rds(df, DB_TOURISM_PATH)
}

# Customer Ticket Booking (Auto-calculated, 10+ tickets 2% discount, unique Booking ID, database persistence)
db_insert_booking <- function(customer_name, destination, travel_date, number_of_tickets, ticket_price = NULL, starting_location = "Chennai", days = 1, season = "All Season", travel_type = "Family") {
  df <- db_get_tourism()
  new_id <- if (nrow(df) > 0) max(c(0, as.numeric(df$id)), na.rm = TRUE) + 1 else 1
  booking_code <- sprintf("B%03d", new_id)
  
  dest_row <- db_get_destination_by_name(destination)
  unit_price <- if (!is.null(ticket_price) && as.numeric(ticket_price) > 0) {
    as.numeric(ticket_price)
  } else if (!is.null(dest_row)) {
    as.numeric(dest_row$base_cost)
  } else {
    1500
  }
  
  tickets_num <- as.numeric(number_of_tickets)
  if (is.na(tickets_num) || tickets_num <= 0) tickets_num <- 1
  
  # Pricing Calculation:
  # Subtotal = Ticket Price * Number of Tickets
  subtotal <- unit_price * tickets_num
  
  # Offer for More Than 10 Tickets:
  # Formula: Discount = Subtotal * 2 / 100
  discount <- if (tickets_num > 10) round(subtotal * 2 / 100) else 0
  final_total_amount <- subtotal - discount
  
  availability <- if (!is.null(dest_row)) dest_row$availability else "Available"
  season_val <- if (!is.null(dest_row) && !is.na(dest_row$popular_season)) dest_row$popular_season else "Summer"
  
  now_str <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  
  new_row <- data.frame(
    id = new_id,
    booking_id = booking_code,
    tourist_name = trimws(customer_name),
    starting_location = trimws(starting_location),
    destination = trimws(destination),
    visitors = tickets_num,
    travel_date = as.character(travel_date),
    days = as.numeric(days),
    season = season_val,
    travel_type = travel_type,
    budget = final_total_amount,
    accommodation = "Yes",
    availability = availability,
    estimated_cost = final_total_amount,
    ticket_price = unit_price,
    subtotal = subtotal,
    discount = discount,
    booking_status = "Confirmed",
    created_at = now_str,
    stringsAsFactors = FALSE
  )
  
  df <- bind_rows(df, new_row)
  db_save_tourism_df(df)
  
  list(
    success = TRUE,
    booking_id = booking_code,
    id = new_id,
    customer_name = trimws(customer_name),
    destination = trimws(destination),
    travel_date = as.character(travel_date),
    number_of_tickets = tickets_num,
    ticket_price = unit_price,
    subtotal = subtotal,
    discount = discount,
    total_amount = final_total_amount,
    booking_status = "Confirmed",
    message = "Ticket Booked Successfully!"
  )
}

db_insert_tourism <- function(tourist_name, starting_location, destination, visitors, travel_date, days, season, travel_type, budget, accommodation) {
  dest_row <- db_get_destination_by_name(destination)
  base_cost <- if (!is.null(dest_row)) as.numeric(dest_row$base_cost) else 3000
  availability <- if (!is.null(dest_row)) dest_row$availability else "Available"
  
  estimated_cost <- (as.numeric(visitors) * as.numeric(days) * base_cost) / 2
  
  df <- db_get_tourism()
  new_id <- if (nrow(df) > 0) max(c(0, as.numeric(df$id)), na.rm = TRUE) + 1 else 1
  booking_code <- sprintf("B%03d", new_id)
  now_str <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  
  new_row <- data.frame(
    id = new_id,
    booking_id = booking_code,
    tourist_name = tourist_name,
    starting_location = starting_location,
    destination = destination,
    visitors = as.numeric(visitors),
    travel_date = travel_date,
    days = as.numeric(days),
    season = season,
    travel_type = travel_type,
    budget = as.numeric(budget),
    accommodation = accommodation,
    availability = availability,
    estimated_cost = estimated_cost,
    ticket_price = base_cost,
    subtotal = as.numeric(budget),
    discount = 0,
    booking_status = "Confirmed",
    created_at = now_str,
    stringsAsFactors = FALSE
  )
  
  df <- bind_rows(df, new_row)
  db_save_tourism_df(df)
  
  list(
    success = TRUE,
    id = new_id,
    booking_id = booking_code,
    estimated_cost = estimated_cost,
    message = "Tourism data saved successfully."
  )
}

db_update_tourism <- function(id, tourist_name, starting_location, destination, visitors, travel_date, days, season, travel_type, budget, accommodation) {
  df <- db_get_tourism()
  target_id <- as.numeric(id)
  
  if (!target_id %in% df$id) {
    return(list(success = FALSE, message = "Record not found in persistent RDS storage."))
  }
  
  idx <- which(df$id == target_id)
  dest_row <- db_get_destination_by_name(destination)
  base_cost <- if (!is.null(dest_row)) as.numeric(dest_row$base_cost) else 3000
  
  df$tourist_name[idx] <- tourist_name
  df$starting_location[idx] <- starting_location
  df$destination[idx] <- destination
  df$visitors[idx] <- as.numeric(visitors)
  df$travel_date[idx] <- travel_date
  df$days[idx] <- as.numeric(days)
  df$season[idx] <- season
  df$travel_type[idx] <- travel_type
  df$budget[idx] <- as.numeric(budget)
  df$accommodation[idx] <- accommodation
  df$estimated_cost[idx] <- (as.numeric(visitors) * as.numeric(days) * base_cost) / 2
  
  db_save_tourism_df(df)
  list(success = TRUE, message = "Tourism record updated successfully.")
}

db_delete_tourism <- function(id) {
  df <- db_get_tourism()
  target_id <- as.numeric(id)
  if (!target_id %in% df$id) {
    return(list(success = FALSE, message = "Record not found in persistent RDS storage."))
  }
  
  df <- df %>% filter(id != target_id)
  db_save_tourism_df(df)
  list(success = TRUE, message = sprintf("Tourism record #%d deleted successfully.", target_id))
}

db_get_customer_bookings <- function(customer_identifier) {
  df <- db_get_tourism()
  if (nrow(df) == 0 || is.null(customer_identifier) || trimws(customer_identifier) == "") {
    return(df[0, ])
  }
  
  c_clean <- tolower(trimws(as.character(customer_identifier)))
  
  match_indices <- sapply(seq_len(nrow(df)), function(i) {
    t_name <- tolower(as.character(df$tourist_name[i]))
    if (t_name == c_clean || grepl(c_clean, t_name, fixed = TRUE)) return(TRUE)
    tokens <- unlist(strsplit(c_clean, "\\s+"))
    tokens <- tokens[nchar(tokens) >= 3]
    if (length(tokens) > 0 && any(sapply(tokens, function(tok) grepl(tok, t_name, fixed = TRUE)))) return(TRUE)
    return(FALSE)
  })
  
  df[match_indices, ] %>% arrange(desc(id))
}

# Auto-initialize
db_init()
