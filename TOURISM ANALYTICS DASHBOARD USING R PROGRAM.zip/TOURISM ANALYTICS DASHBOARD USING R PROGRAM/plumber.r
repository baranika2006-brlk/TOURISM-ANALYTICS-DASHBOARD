# ==============================================================================
# TOURISM ANALYTICS DASHBOARD - PLUMBER REST API ROUTER (plumber.r)
# Technology: Pure R Programming Backend with Pure R Database Engine
# Modules: database.r (RDS Storage Layer), data_analytics.r (dplyr Analytics)
# Resilience: Robust CORS preflight, safe body parser & zero-crash route handlers
# ==============================================================================

suppressPackageStartupMessages({
  library(plumber)
  library(jsonlite)
  library(dplyr)
})

# Source Pure R Database & Analytics Modules
if (file.exists("database.r")) {
  source("database.r")
} else {
  source("database.R")
}

if (file.exists("data_analytics.r")) {
  source("data_analytics.r")
} else {
  source("data_analytics.R")
}

#* @apiTitle Tourism Analytics Dashboard REST API
#* @apiDescription Pure R Programming REST API with pure R database engine & dplyr analytics.
#* @apiVersion 1.0.0

#* CORS Filter
#* @filter cors
function(req, res) {
  res$setHeader("Access-Control-Allow-Origin", "*")
  res$setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
  res$setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With, Accept, Access-Control-Request-Private-Network")
  res$setHeader("Access-Control-Allow-Private-Network", "true")
  res$setHeader("Access-Control-Max-Age", "86400")
  
  method <- if (!is.null(req$REQUEST_METHOD)) as.character(req$REQUEST_METHOD) else if (!is.null(req$rook.env$REQUEST_METHOD)) as.character(req$rook.env$REQUEST_METHOD) else ""
  if (identical(toupper(method), "OPTIONS")) {
    res$status <- 200
    return(list(status = "ok"))
  } else {
    plumber::forward()
  }
}

# Helper to parse incoming JSON bodies safely across all Plumber/Rook environments
parse_json_body <- function(req) {
  # 1. Already parsed list
  if (!is.null(req$body) && is.list(req$body) && length(req$body) > 0) return(req$body)
  
  # 2. Raw bytes body
  if (!is.null(req$body) && is.raw(req$body) && length(req$body) > 0) {
    txt <- tryCatch(rawToChar(req$body), error = function(e) "")
    if (nchar(txt) > 0) {
      res <- tryCatch(jsonlite::fromJSON(txt, simplifyVector = FALSE), error = function(e) list())
      if (is.list(res) && length(res) > 0) return(res)
    }
  }
  
  # 3. String body
  if (!is.null(req$body) && is.character(req$body) && length(req$body) > 0) {
    txt <- paste(req$body, collapse = "\n")
    if (nchar(trimws(txt)) > 0) {
      res <- tryCatch(jsonlite::fromJSON(txt, simplifyVector = FALSE), error = function(e) list())
      if (is.list(res) && length(res) > 0) return(res)
    }
  }
  
  # 4. postBody
  if (!is.null(req$postBody) && is.character(req$postBody) && length(req$postBody) > 0) {
    txt <- paste(req$postBody, collapse = "\n")
    if (nchar(trimws(txt)) > 0) {
      res <- tryCatch(jsonlite::fromJSON(txt, simplifyVector = FALSE), error = function(e) list())
      if (is.list(res) && length(res) > 0) return(res)
    }
  }
  
  # 5. Rook input stream
  if (!is.null(req$rook.input) && !is.null(req$rook.input$read)) {
    txt <- tryCatch({
      req$rook.input$rewind()
      rawToChar(req$rook.input$read())
    }, error = function(e) "")
    if (nchar(trimws(txt)) > 0) {
      res <- tryCatch(jsonlite::fromJSON(txt, simplifyVector = FALSE), error = function(e) list())
      if (is.list(res) && length(res) > 0) return(res)
    }
  }
  
  return(list())
}

#* Health Check API (Active Keepalive & Heartbeat Probe)
#* @get /api/health
#* @serializer json
function(res) {
  res$setHeader("Access-Control-Allow-Origin", "*")
  res$setHeader("Access-Control-Allow-Private-Network", "true")
  return(list(
    status = "online",
    service = "Tourism Analytics Dashboard (Pure R Plumber)",
    version = "1.0.0",
    server_time = as.character(Sys.time())
  ))
}

# ==============================================================================
# STATIC FRONTEND SERVING
# ==============================================================================

#* Serve Web Application
#* @get /
#* @serializer html
function(res) {
  res$setHeader("Content-Type", "text/html; charset=utf-8")
  res$setHeader("Access-Control-Allow-Origin", "*")
  target_file <- "public/index.html"
  if (file.exists(target_file)) {
    lines <- readLines(target_file, warn = FALSE, encoding = "UTF-8")
    paste(lines, collapse = "\n")
  } else {
    "<h1>Tourism Analytics Dashboard</h1><p>Frontend file not found in public/index.html.</p>"
  }
}

#* Serve Stylesheet
#* @get /style.css
#* @serializer contentType list(type="text/css; charset=utf-8")
function(res) {
  res$setHeader("Content-Type", "text/css; charset=utf-8")
  res$setHeader("Access-Control-Allow-Origin", "*")
  target_file <- "public/style.css"
  if (file.exists(target_file)) {
    lines <- readLines(target_file, warn = FALSE, encoding = "UTF-8")
    paste(lines, collapse = "\n")
  } else {
    ""
  }
}

# ==============================================================================
# 1. ADMIN AUTHENTICATION & USER MANAGEMENT (Pure R Database)
# ==============================================================================

#* Admin / Universal Login API (Seamless Smart Router)
#* @post /api/login
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    username <- if (!is.null(body$username)) body$username else body$identifier
    password <- body$password
    
    if (is.null(username) || is.null(password) || trimws(as.character(username)) == "" || trimws(as.character(password)) == "") {
      res$status <- 400
      return(list(success = FALSE, message = "Please enter Username and Password."))
    }
    
    auth_res <- db_authenticate(username, password)
    if (isTRUE(auth_res$authenticated)) {
      return(list(
        success = TRUE,
        role = auth_res$role,
        role_type = if (!is.null(auth_res$role_type)) auth_res$role_type else auth_res$role,
        is_admin = isTRUE(auth_res$is_admin),
        is_customer = isTRUE(auth_res$is_customer),
        message = auth_res$message,
        user = if (!is.null(auth_res$user)) auth_res$user else auth_res$customer,
        customer = auth_res$customer
      ))
    } else {
      res$status <- 401
      return(list(success = FALSE, message = auth_res$message))
    }
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Authentication error:", e$message)))
  })
}

#* Universal Single Sign-On API (Checks both Admins and Customers)
#* @post /api/auth/login
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    username <- if (!is.null(body$username)) body$username else body$identifier
    password <- body$password
    
    if (is.null(username) || is.null(password) || trimws(as.character(username)) == "" || trimws(as.character(password)) == "") {
      res$status <- 400
      return(list(success = FALSE, message = "Please enter Username/Email and Password."))
    }
    
    auth_res <- db_universal_authenticate(username, password)
    if (isTRUE(auth_res$authenticated)) {
      return(list(
        success = TRUE,
        role = auth_res$role,
        role_type = auth_res$role_type,
        is_admin = isTRUE(auth_res$is_admin),
        is_customer = isTRUE(auth_res$is_customer),
        message = auth_res$message,
        user = auth_res$user,
        customer = auth_res$customer
      ))
    } else {
      res$status <- 401
      return(list(success = FALSE, message = auth_res$message))
    }
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Authentication error:", e$message)))
  })
}

#* Admin Registration / Admin Creation API
#* @post /api/admin/register
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    username <- trimws(as.character(body$username))
    password <- trimws(as.character(body$password))
    confirm_password <- trimws(as.character(body$confirm_password))
    full_name <- trimws(as.character(body$full_name))
    email <- ifelse(!is.null(body$email), trimws(as.character(body$email)), "")
    department <- ifelse(!is.null(body$department), trimws(as.character(body$department)), "Directorate of Tourism")
    
    if (is.null(username) || username == "" || is.null(password) || password == "" || is.null(full_name) || full_name == "") {
      res$status <- 400
      return(list(success = FALSE, message = "Admin Name, Username, and Password are required."))
    }
    
    if (!is.null(body$confirm_password) && password != confirm_password) {
      res$status <- 400
      return(list(success = FALSE, message = "Passwords do not match."))
    }
    
    reg_res <- db_register_admin(username, password, full_name, email, department)
    if (!isTRUE(reg_res$success)) {
      res$status <- 400
    }
    return(reg_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Registration error:", e$message)))
  })
}

#* Get Users List
#* @get /api/users
#* @serializer json
function(res) {
  tryCatch({
    users_df <- db_get_users()
    list(
      success = TRUE,
      count = nrow(users_df),
      users = users_df %>% select(id, username, full_name, role, department, status, last_login)
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Error loading users:", e$message), users = list())
  })
}

#* Add User Account
#* @post /api/users
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    username <- trimws(as.character(body$username))
    password <- trimws(as.character(body$password))
    full_name <- ifelse(!is.null(body$full_name), trimws(as.character(body$full_name)), username)
    email <- ifelse(!is.null(body$email), trimws(as.character(body$email)), "")
    role <- ifelse(!is.null(body$role), as.character(body$role), "Admin Staff")
    department <- ifelse(!is.null(body$department), as.character(body$department), "Tourism")
    
    if (is.null(username) || username == "" || is.null(password) || password == "") {
      res$status <- 400
      return(list(success = FALSE, message = "Username and password are required."))
    }
    
    db_res <- db_add_user(username, password, full_name, email, role, department)
    if (!isTRUE(db_res$success)) res$status <- 400
    return(db_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Error adding user:", e$message)))
  })
}

#* Delete User Account
#* @delete /api/users/<id>
#* @serializer json
function(id, res) {
  tryCatch({
    db_res <- db_delete_user(id)
    if (!isTRUE(db_res$success)) res$status <- 400
    return(db_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Error deleting user:", e$message)))
  })
}

# ==============================================================================
# 2. CUSTOMER REGISTER & CUSTOMER SIGN IN (Pure R Engine)
# ==============================================================================

#* Customer Registration API (Input-based vs customers.rds)
#* @post /api/customer/register
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    username <- trimws(as.character(body$username))
    password <- trimws(as.character(body$password))
    confirm_password <- trimws(as.character(body$confirm_password))
    full_name <- trimws(as.character(body$full_name))
    email <- ifelse(!is.null(body$email), trimws(as.character(body$email)), "")
    phone <- ifelse(!is.null(body$phone), trimws(as.character(body$phone)), "")
    city <- ifelse(!is.null(body$city) && trimws(as.character(body$city)) != "", trimws(as.character(body$city)), "Chennai")
    
    if (is.null(username) || username == "" || is.null(password) || password == "" || is.null(full_name) || full_name == "") {
      res$status <- 400
      return(list(success = FALSE, message = "Please fill all required fields."))
    }
    
    if (!is.null(body$confirm_password) && password != confirm_password) {
      res$status <- 400
      return(list(success = FALSE, message = "Passwords do not match."))
    }
    
    reg_res <- db_register_customer(username, password, full_name, email, phone, city)
    if (!isTRUE(reg_res$success)) {
      res$status <- 400
    }
    return(reg_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Customer registration error:", e$message)))
  })
}

#* Customer Sign In API (Seamless Smart Router)
#* @post /api/customer/login
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    username <- if (!is.null(body$username)) body$username else body$identifier
    password <- body$password
    
    if (is.null(username) || is.null(password) || trimws(as.character(username)) == "" || trimws(as.character(password)) == "") {
      res$status <- 400
      return(list(success = FALSE, message = "Please enter Username/Email and Password."))
    }
    
    auth_res <- db_authenticate_customer(username, password)
    if (isTRUE(auth_res$authenticated)) {
      return(list(
        success = TRUE,
        role = auth_res$role,
        role_type = if (!is.null(auth_res$role_type)) auth_res$role_type else auth_res$role,
        is_admin = isTRUE(auth_res$is_admin),
        is_customer = isTRUE(auth_res$is_customer),
        message = auth_res$message,
        customer = if (!is.null(auth_res$customer)) auth_res$customer else auth_res$user,
        user = if (!is.null(auth_res$user)) auth_res$user else auth_res$customer
      ))
    } else {
      res$status <- 401
      return(list(success = FALSE, message = auth_res$message))
    }
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Customer sign in error:", e$message)))
  })
}

#* Get All Customers List API
#* @get /api/customers
#* @serializer json
function(res) {
  tryCatch({
    cust_df <- db_get_customers()
    list(
      success = TRUE,
      count = nrow(cust_df),
      customers = cust_df %>% select(id, username, full_name, email, phone, city, created_at, last_login)
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Error loading customers:", e$message), customers = list())
  })
}

#* Global Database Sync & State Bootstrap API
#* @get /api/sync
#* @serializer json
function(res) {
  tryCatch({
    users_df <- db_get_users()
    cust_df <- db_get_customers()
    dest_df <- db_get_destinations()
    tourism_df <- db_get_tourism_data()
    
    list(
      success = TRUE,
      users = users_df,
      customers = cust_df,
      destinations = dest_df,
      tourism = tourism_df,
      total_users = nrow(users_df),
      total_customers = nrow(cust_df)
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Sync error:", e$message))
  })
}

#* Customer Profile Update API
#* @put /api/customer/profile
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    id <- body$id
    full_name <- ifelse(!is.null(body$full_name), as.character(body$full_name), "")
    email <- ifelse(!is.null(body$email), as.character(body$email), "")
    phone <- ifelse(!is.null(body$phone), as.character(body$phone), "")
    city <- ifelse(!is.null(body$city), as.character(body$city), "")
    new_password <- ifelse(!is.null(body$new_password), as.character(body$new_password), "")
    
    if (is.null(id)) {
      res$status <- 400
      return(list(success = FALSE, message = "Customer ID is required."))
    }
    
    update_res <- db_update_customer_profile(id, full_name, email, phone, city, new_password)
    if (!isTRUE(update_res$success)) res$status <- 400
    return(update_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Profile update error:", e$message)))
  })
}

#* Customer Tour Ticket Booking API (Auto-calculated, 10+ tickets 2% discount, Booking ID generated, DB saved)
#* @post /api/customer/book
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    customer_name <- trimws(as.character(body$customer_name))
    if (customer_name == "" && !is.null(body$tourist_name)) customer_name <- trimws(as.character(body$tourist_name))
    
    destination <- trimws(as.character(body$destination))
    travel_date <- as.character(body$travel_date)
    number_of_tickets <- as.numeric(body$number_of_tickets)
    if (is.na(number_of_tickets) && !is.null(body$visitors)) number_of_tickets <- as.numeric(body$visitors)
    
    ticket_price <- if (!is.null(body$ticket_price)) as.numeric(body$ticket_price) else NULL
    origin <- ifelse(!is.null(body$starting_location) && body$starting_location != "", as.character(body$starting_location), "Chennai")
    days <- ifelse(!is.null(body$days) && as.numeric(body$days) > 0, as.numeric(body$days), 1)
    travel_type <- ifelse(!is.null(body$travel_type), as.character(body$travel_type), "Family")
    
    if (is.null(customer_name) || customer_name == "" ||
        is.null(destination) || destination == "" ||
        is.null(travel_date) || travel_date == "" ||
        is.na(number_of_tickets) || number_of_tickets <= 0) {
      res$status <- 400
      return(list(success = FALSE, message = "Please fill in all booking details (Destination, Travel Date, and Number of Tickets)."))
    }
    
    dest_row <- db_get_destination_by_name(destination)
    if (is.null(dest_row)) {
      res$status <- 404
      return(list(success = FALSE, message = "Selected destination does not exist in the database."))
    }
    
    save_res <- db_insert_booking(
      customer_name = customer_name,
      destination = destination,
      travel_date = travel_date,
      number_of_tickets = number_of_tickets,
      ticket_price = ticket_price,
      starting_location = origin,
      days = days,
      travel_type = travel_type
    )
    
    return(save_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Ticket booking error:", e$message)))
  })
}

#* Get Customer's Own Bookings (Filtered by customer identity)
#* @get /api/customer/bookings
#* @serializer json
function(customer_name = "", res) {
  tryCatch({
    df <- db_get_customer_bookings(customer_name)
    list(
      success = TRUE,
      count = nrow(df),
      data = df
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Error loading customer bookings:", e$message), data = list())
  })
}

# ==============================================================================
# 3. DESTINATIONS (Pure R Database)
# ==============================================================================

#* Get All Destinations
#* @get /api/destinations
#* @serializer json
function(res) {
  tryCatch({
    dests_df <- db_get_destinations()
    list(
      success = TRUE,
      count = nrow(dests_df),
      destinations = dests_df
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Error loading destinations:", e$message), destinations = list())
  })
}

#* Admin Add Destination API
#* @post /api/destinations
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    name <- trimws(as.character(body$name))
    location <- ifelse(!is.null(body$location) && body$location != "", trimws(as.character(body$location)), "Tamil Nadu")
    ticket_price <- as.numeric(body$ticket_price)
    if (is.na(ticket_price) && !is.null(body$base_cost)) ticket_price <- as.numeric(body$base_cost)
    availability <- ifelse(!is.null(body$availability) && body$availability != "", trimws(as.character(body$availability)), "Available")
    popular_season <- ifelse(!is.null(body$popular_season), as.character(body$popular_season), "All Season")
    description <- ifelse(!is.null(body$description), as.character(body$description), "")
    
    if (name == "") {
      res$status <- 400
      return(list(success = FALSE, message = "Destination name is required."))
    }
    if (is.na(ticket_price) || ticket_price <= 0) {
      res$status <- 400
      return(list(success = FALSE, message = "Please enter a valid ticket price."))
    }
    
    add_res <- db_add_destination(
      name = name,
      location = location,
      ticket_price = ticket_price,
      availability = availability,
      popular_season = popular_season,
      category = location,
      description = description
    )
    
    return(add_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Error adding destination:", e$message)))
  })
}

#* Admin Delete Destination API
#* @delete /api/destinations/<id>
#* @serializer json
function(id, res) {
  tryCatch({
    del_res <- db_delete_destination(id)
    if (!isTRUE(del_res$success)) res$status <- 400
    return(del_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Error deleting destination:", e$message)))
  })
}

#* Check Destination Availability & Calculate Estimated Cost
#* @post /api/check-availability
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    dest_name <- body$destination
    visitors <- as.numeric(body$visitors)
    days <- as.numeric(body$days)
    
    if (is.null(dest_name) || trimws(as.character(dest_name)) == "" || is.na(visitors) || is.na(days)) {
      res$status <- 400
      return(list(success = FALSE, message = "Destination, visitors, and days are required."))
    }
    
    dest <- db_get_destination_by_name(dest_name)
    if (is.null(dest)) {
      res$status <- 404
      return(list(success = FALSE, message = "Destination not found in database."))
    }
    
    base_cost <- as.numeric(dest$base_cost)
    subtotal <- visitors * base_cost
    discount <- if (visitors > 10) round(subtotal * 2 / 100) else 0
    final_cost <- subtotal - discount
    
    recommendation <- if (dest$availability == "Limited") {
      sprintf("Peak high-demand season for %s. Advance booking is strongly advised.", dest$name)
    } else if (dest$visitor_level == "Very High") {
      sprintf("High tourist footfall. Morning visits recommended for %s.", dest$name)
    } else {
      sprintf("Smooth travel flow. Ideal for %s season travel!", dest$popular_season)
    }
    
    list(
      success = TRUE,
      destination = dest$name,
      base_cost = base_cost,
      ticket_price = base_cost,
      popular_season = dest$popular_season,
      availability = dest$availability,
      visitor_level = dest$visitor_level,
      description = dest$description,
      visitors = visitors,
      days = days,
      subtotal = subtotal,
      discount = discount,
      estimated_cost = final_cost,
      total_amount = final_cost,
      recommendation = recommendation
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Availability calculation error:", e$message))
  })
}

# ==============================================================================
# 4. TOURISM DATA COLLECTION (Pure R Database)
# ==============================================================================

#* Save Tourism Record
#* @post /api/tourism
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    
    tourist_name <- trimws(as.character(body$tourist_name))
    starting_location <- trimws(as.character(body$starting_location))
    destination <- trimws(as.character(body$destination))
    visitors <- as.numeric(body$visitors)
    travel_date <- as.character(body$travel_date)
    days <- as.numeric(body$days)
    season <- as.character(body$season)
    travel_type <- as.character(body$travel_type)
    budget_raw <- as.character(body$budget)
    budget <- as.numeric(gsub("[^0-9.]", "", budget_raw))
    if (is.na(budget)) budget <- 0
    accommodation <- ifelse(!is.null(body$accommodation) && body$accommodation != "", as.character(body$accommodation), "Yes")
    
    if (is.null(tourist_name) || tourist_name == "" ||
        is.null(starting_location) || starting_location == "" ||
        is.null(destination) || destination == "" ||
        is.na(visitors) || visitors <= 0 ||
        is.null(travel_date) || travel_date == "" ||
        is.na(days) || days <= 0 ||
        is.null(season) || season == "" ||
        is.null(travel_type) || travel_type == "") {
      res$status <- 400
      return(list(success = FALSE, message = "All form fields must be valid."))
    }
    
    db_insert_tourism(tourist_name, starting_location, destination, visitors, travel_date, days, season, travel_type, budget, accommodation)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Error saving tourism record:", e$message)))
  })
}

#* Update Tourism Record
#* @put /api/tourism/<id>
#* @serializer json
function(id, req, res) {
  tryCatch({
    body <- parse_json_body(req)
    budget_raw <- as.character(body$budget)
    budget <- as.numeric(gsub("[^0-9.]", "", budget_raw))
    if (is.na(budget)) budget <- 0
    
    db_res <- db_update_tourism(
      id,
      tourist_name = body$tourist_name,
      starting_location = body$starting_location,
      destination = body$destination,
      visitors = body$visitors,
      travel_date = body$travel_date,
      days = body$days,
      season = body$season,
      travel_type = body$travel_type,
      budget = budget,
      accommodation = body$accommodation
    )
    if (!isTRUE(db_res$success)) res$status <- 400
    return(db_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Error updating record:", e$message)))
  })
}

#* Get All Tourism Records with Filtering
#* @get /api/tourism
#* @serializer json
function(destination = "", season = "", travel_type = "", search = "", res) {
  tryCatch({
    df <- db_get_tourism(destination, season, travel_type, search)
    list(
      success = TRUE,
      count = nrow(df),
      data = df
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Error retrieving tourism records:", e$message), data = list())
  })
}

#* Get Single Tourism Record by ID
#* @get /api/tourism/<id>
#* @serializer json
function(id, res) {
  tryCatch({
    df <- db_get_tourism()
    rec <- df %>% filter(id == as.numeric(!!id))
    if (nrow(rec) > 0) {
      return(list(success = TRUE, data = as.list(rec[1, ])))
    } else {
      res$status <- 404
      return(list(success = FALSE, message = "Tourism record not found."))
    }
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Error retrieving record:", e$message)))
  })
}

#* Delete Tourism Record Permanently
#* @delete /api/tourism/<id>
#* @serializer json
function(id, res) {
  tryCatch({
    db_res <- db_delete_tourism(id)
    if (!isTRUE(db_res$success)) res$status <- 400
    return(db_res)
  }, error = function(e) {
    res$status <- 500
    return(list(success = FALSE, message = paste("Error deleting record:", e$message)))
  })
}

#* Turnstile Gate Entry Simulation
#* @post /api/simulator/entry
#* @serializer json
function(req, res) {
  tryCatch({
    body <- parse_json_body(req)
    destination <- ifelse(!is.null(body$destination) && body$destination != "", body$destination, "Chennai")
    visitors <- ifelse(!is.null(body$visitors), as.numeric(body$visitors), 2)
    origin <- ifelse(!is.null(body$origin) && body$origin != "", body$origin, "Simulator Gate 1")
    
    dest <- db_get_destination_by_name(destination)
    base_cost <- if (!is.null(dest)) as.numeric(dest$base_cost) else 3000
    budget <- visitors * base_cost
    
    db_res <- db_insert_tourism(
      tourist_name = sprintf("Gate Tourist #%d", sample(1000:9999, 1)),
      starting_location = origin,
      destination = destination,
      visitors = visitors,
      travel_date = format(Sys.Date(), "%Y-%m-%d"),
      days = 1,
      season = "Summer",
      travel_type = "Solo",
      budget = budget,
      accommodation = "No"
    )
    
    list(
      success = TRUE,
      message = sprintf("Sensor entry logged: %d tourists admitted at %s gate.", visitors, destination),
      new_id = db_res$id
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Simulation error:", e$message))
  })
}

# ==============================================================================
# 5. DATA ANALYSIS (Pure R Analytics Engine)
# ==============================================================================

#* Aggregate R Data Analysis (Module 3)
#* @get /api/analysis
#* @serializer json
function(destination = "", season = "", travel_type = "", res) {
  tryCatch({
    df <- db_get_tourism(destination, season, travel_type)
    
    total_trips <- calculate_total_trips(df)
    total_visitors <- calculate_total_visitors(df)
    avg_visitors <- calculate_average_visitors(df)
    total_revenue <- calculate_total_revenue(df)
    avg_duration <- calculate_average_trip_duration(df)
    most_visited <- find_most_visited_destination(df)
    highest_revenue <- find_highest_revenue_destination(df)
    popular_season <- find_popular_season(df)
    common_travel_type <- find_common_travel_type(df)
    insight <- generate_tourism_insight(df)
    
    list(
      success = TRUE,
      total_trips = total_trips,
      total_visitors = total_visitors,
      avg_visitors = avg_visitors,
      total_revenue = total_revenue,
      avg_trip_duration = avg_duration,
      most_visited_destination = most_visited,
      highest_revenue_destination = highest_revenue,
      popular_season = popular_season,
      common_travel_type = common_travel_type,
      tourism_insight = insight,
      seasonal_matrix = compute_seasonal_matrix(df),
      origin_matrix = compute_origin_matrix(df)
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Analysis error:", e$message))
  })
}

#* Live R Statistical Computing & Machine Learning Models
#* @get /api/r-analytics
#* @serializer json
function(res) {
  tryCatch({
    df <- db_get_tourism()
    ml_res <- compute_r_machine_learning(df)
    list(
      success = TRUE,
      linear_regression = ml_res$linear_regression,
      correlation_analysis = ml_res$correlation_analysis,
      kmeans_clustering = ml_res$kmeans_clustering
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Machine learning analytics error:", e$message))
  })
}

# ==============================================================================
# 6. VISUALIZATION DASHBOARD (Pure R Aggregations)
# ==============================================================================

#* Visualization Datasets (Module 4)
#* @get /api/visualization
#* @serializer json
function(season = "", destination = "", res) {
  tryCatch({
    df <- db_get_tourism(destination, season)
    vis_data <- compute_visualization_data(df)
    list(
      success = TRUE,
      visitors_by_destination = vis_data$visitors_by_destination,
      revenue_by_destination = vis_data$revenue_by_destination,
      trips_by_destination = vis_data$trips_by_destination
    )
  }, error = function(e) {
    res$status <- 500
    list(
      success = FALSE,
      message = paste("Visualization data error:", e$message),
      visitors_by_destination = list(),
      revenue_by_destination = list(),
      trips_by_destination = list()
    )
  })
}

# ==============================================================================
# 7. REPORTS GENERATION (Pure R Report Engine)
# ==============================================================================

#* Comprehensive Tourism Analytics Report (Module 5)
#* @get /api/report
#* @serializer json
function(destination = "", season = "", res) {
  tryCatch({
    df <- db_get_tourism(destination, season)
    
    report_date <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
    total_trips <- calculate_total_trips(df)
    total_visitors <- calculate_total_visitors(df)
    avg_visitors <- calculate_average_visitors(df)
    total_revenue <- calculate_total_revenue(df)
    avg_duration <- calculate_average_trip_duration(df)
    most_visited <- find_most_visited_destination(df)
    highest_revenue <- find_highest_revenue_destination(df)
    popular_season <- find_popular_season(df)
    common_travel_type <- find_common_travel_type(df)
    
    list(
      success = TRUE,
      report_title = "TOURISM ANALYTICS REPORT",
      report_date = report_date,
      total_trips = total_trips,
      total_visitors = total_visitors,
      avg_visitors = avg_visitors,
      total_revenue = total_revenue,
      most_visited_destination = most_visited,
      highest_revenue_destination = highest_revenue,
      avg_trip_duration = avg_duration,
      popular_season = popular_season,
      common_travel_type = common_travel_type,
      records = df
    )
  }, error = function(e) {
    res$status <- 500
    list(success = FALSE, message = paste("Report generation error:", e$message), records = list())
  })
}
